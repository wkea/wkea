# Launchpad Firmware Utility

[![Netlify Status](https://api.netlify.com/api/v1/badges/903cec3c-f36f-46c4-ad26-462392ebffbd/deploy-status)](https://app.netlify.com/sites/lp-firmware-utility/deploys)

### Novation Launchpad firmware updating and patching on the web

### https://fw.mat1jaczyyy.com

Launchpad Firmware Utility is a small web tool which allows you to update your Launchpad's firmware and apply patches to it in mere seconds.

Extra hidden features (Konami code):

* Custom SysEx file flashing
* ;)

export const headers: any = {
  firmware: "Firmware",
  palette: "Palette",
  modes: "Custom Modes"
};
import { RootStore } from ".";

export default class Store {
  constructor(public rootStore: RootStore) {}
}

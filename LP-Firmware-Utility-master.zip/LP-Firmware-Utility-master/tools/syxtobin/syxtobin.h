#ifndef SYXTOBIN_H
#define SYXTOBIN_H

byte convert_syxtobin();

#endif
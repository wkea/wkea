#ifndef PATCHES_H
#define PATCHES_H

#include "common.h"

void patch(const byte family, const byte target, const byte index, bool* args, byte* palette);

#endif
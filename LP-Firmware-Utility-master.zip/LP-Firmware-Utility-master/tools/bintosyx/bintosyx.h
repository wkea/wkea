#ifndef BINTOSYX_H
#define BINTOSYX_H

void convert_bintosyx();

#endif